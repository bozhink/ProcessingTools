Delivery notes:

The enclosed Relax NG Schema contains several modules:

MAIN MODULE:
archivearticle.rng

SUBORDINATE MODULES:
archivecustom-classes.ent.rng
archivecustom-mixes.ent.rng
archivecustom-models.ent.rng
articlemeta.ent.rng
backmatter.ent.rng
chars.ent.rng
common.ent.rng
default-classes.ent.rng
default-mixes.ent.rng
display.ent.rng
format.ent.rng
htmltable.rng
journalmeta.ent.rng
link.ent.rng
list.ent.rng
math.ent.rng
mathml2.rng
mathml2-qname-1.mod.rng
mathmlsetup.ent.rng
para.ent.rng
phrase.ent.rng
readme.txt
references.ent.rng
section.ent.rng
XHTMLtablesetup.ent.rng


THIS SCHEMA IS NOT INTENDED FOR MAINTENANCE. This Schema has been generated automatically from the corresponding NCBI DTD. While the structural constraints on document tagging expressed by this schema are identical to those of the DTD, changes to the schema are best made by making the analogous changes to the DTD, and regenerating a schema from the modified DTD.

The Schema has been tested and found to perform properly in James Clark's Jing Validator running in syncROsoft oXygen (version 6.2).
